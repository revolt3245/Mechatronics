/* Main.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "USBMon.h"

float LookupTable[200];
unsigned int reference;

void InitEXINTF()
{
	// Disable SSCEN, CLK1EN, CLK2EN
	*GBLCTL &= 0xFFFFFFC7;

	// WriteSetup[31:28] | WriteStrobe[27:22] | WriteHold[21:20] | ReadSetup[19:16] | 
	// RSVD[15:14] | ReadStrobe[13:8] | RSVD[7] | MType[6:4] | RSVD[3:2] | ReadHold[1:0]
	// DEFAULT = (0xF<<28)|(0x3F<<22)|(0x3<<20)|(0xF<<16)|(0x3F<<8)|(0x2<<4)|(0x3);
	// SRAM
	*CECTL0 = (0x0<<28)|(0x03<<22)|(0x1<<20)|(0x0<<16)|(0x03<<8)|(0x2<<4)|(0x1);

	// IO Space: Async 32bit Mode, Setup 2 and Strobe 5, Hold 1  
	*CECTL2 = (0x2<<28)|(0x05<<22)|(0x1<<20)|(0x2<<16)|(0x05<<8)|(0x2<<4)|(0x1);
}

void InitTimer()
{
	// Hold 0 and Go 0, Internal Clock Source (160Mhz/4), Clock Mode   
	*T0CTL |= 0x00000300;

	// Timer Period
	*T0PRD = (CPU_FRQ/4.0f)/(2.0f*TIMER_FRQ);	// f = 40Mhz/2*Period 

	// Hold 1 and Go 1   
	*T0CTL |= 0x000000C0;
}

void InitINT()
{
	// Enable CPU Interrupt INT06(EXTINT6), INT14(TINT0) and NMI
	IER |= 0x00004042;
}

void GIE()
{
	// Global Interrupt Enable
	CSR |= 0x00000001;
}

// Caution: The delayed time is not exact.
void delay_us(unsigned int time_us)
{
	register unsigned int i;

	for (i = 0; i < (time_us * 14); i++) ;
}

// Caution: The delayed time is not exact.
void delay_ms(unsigned int time_ms)
{
	register unsigned int i;

	for (i = 0; i < time_ms; i++) {
		delay_us(1000);
	}
}

// Wait until timer interrupt
void WaitTFlag()
{
	while (!TFlag) ;
	TFlag = 0;
}

// Waiting time = (Timer Period) * cnt
void WaitTFlagCnt(unsigned int cnt)
{
	unsigned int i;

	TFlag = 0;

	for (i=0; i<cnt; i++) {
		WaitTFlag();
	}
}

void halfstep(float ms){
	static int count = 0;
	*STEPPER = 0x2;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0xa;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0x8;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0x9;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0x1;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));		// /A
	delay_ms(ms);

	*STEPPER = 0x5;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0x4;		// /B
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);

	*STEPPER = 0x6;
	MACRO_PRINT((tmp_string, "\r\ncount : %d\r\n", ++count));
	delay_ms(ms);
}

/*
void OneStepMove(unsigned int dir, unsiged int tDelay){

}
*/

unsigned char state[8] = {0x2,0xa,0x8,0x9,0x1,0x5,0x4,0x6};

void OneStepMove(unsigned int dir, unsigned int tDelay){
	int seq;
	static int index = 0;
	if(dir == 0){
		seq = 1;
	}
	if(dir == 1){
		seq = -1;
	}
	WaitTFlagCnt(tDelay);
	index += seq;
	index %= 8;
	if(index < 0){
		index += 8;
	}

	*STEPPER = state[index];
	
}

void StepMoveCV(float angle, float rps){
	int StepNum;
	unsigned int IntNum;
	unsigned int dir;
	int i;

	StepNum = (int)(angle/0.9f);
	dir = (StepNum>0)? 0:1;
	StepNum = (StepNum>0)? StepNum:-StepNum;
	IntNum = (unsigned int)(250.0f/rps);

	for(i=0; i<StepNum; i++){
		OneStepMove(dir, IntNum);
	}
}

unsigned int MakeVelProfile(float maxVel, float accel){
	unsigned int i;
	float MinTime;

	MinTime = (250.0f*360.0f)/maxVel;

	for(i = 0; i < 200; i++){
		LookupTable[i] = sqrt(0.9f/(2.0f*accel*(i+1.0f)))*100000.0f;
		if(MinTime > LookupTable[i]){
			break;
		}
	}
	return i;
}

void StepMoveVP(unsigned int dir, float angle, float maxVel, float accel){
	static int idx = 0;
	int objstep;
	static int step = 0;
	float MinTime;
	unsigned int rs1, rs2;

	objstep = (int)(angle/0.9f);

	rs1 = MakeVelProfile(maxVel, accel);
	rs2 = objstep - rs1;
	MinTime = (250.0f*360.0f)/maxVel;
	
	if(rs2 <= rs1){
		if(step >= objstep/2){
			idx--;
			reference = (unsigned int)LookupTable[idx];
			//OneStepMove(dir, reference);
		}
		else if(step < objstep){
			reference = (unsigned int)LookupTable[idx];
			//OneStepMove(dir, reference);
			idx++;
		}
		else{
			step = objstep;
		}
	}
	else{
		if(step < rs1){
			reference = (unsigned int)LookupTable[idx];
			//OneStepMove(dir, reference);
			idx++;
		}
		else if((step < rs2) && (step >= rs1)){
			reference = (unsigned int)MinTime;
			//OneStepMove(dir, reference);
		}
		else if((step < objstep) && (step >= rs2)){
			idx--;
			reference = (unsigned int)LookupTable[idx];
			//OneStepMove(dir, reference);
		}
		else{
			step = objstep;
		}
	}
	step++;
	MACRO_PRINT((tmp_string, "\r\n%u\r\n", reference));
	delay_ms(100);
}

void main()
{
	int i = 0;
	InitEXINTF();	// Asynchronous Bus Initialization
	InitTimer();	// Timer Initialization
	InitUART();		// UART Initialization
	InitINT();		// Interrupt Enable(External INT and Timer INT)
	InitUSBMon();	// USB Monitor Initialization

	MACRO_PRINT((tmp_string, "\r\nMechatronics Course EIE SeoulTech %d\r\n", 2016));
	MACRO_PRINT((tmp_string, "\r\nFPGA Ver%2x.%02x\r\n\n", ((*FPGAVER>>8) & 0xFF), (*FPGAVER & 0xFF)));

	TFlag = 0;

	GIE();

	//WaitTFlagCnt(1000);

	//MACRO_PRINT((tmp_string, "\r\n%u\r\n", MakeVelProfile(15000.0f, 15000.0f)));
	while (1){
		StepMoveVP(0, 720.0f, 1500.0f, 4000.0f);
		//StepMoveCV(360, 3.0f);
	}
}

