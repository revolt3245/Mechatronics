/* Interupt.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "interrupt.h"
#include "USBMon.h"

extern unsigned int tdelay;

//unsigned char state[8] = {0x2,0xa,0x8,0x9,0x1,0x5,0x4,0x6};

/*
void OneStepMove(unsigned int dir, unsigned int tDelay){
	int seq;
	static int count = 0;
	static int index = 0;
	if(dir == 0){
		seq = 1;
	}
	if(dir == 1){
		seq = -1;
	}

	count++;
	if(count >= tDelay){
		index += seq;
		index %= 8;
		if(index < 0){
			index += 8;
		}
		
		count = 0;
	}
	*STEPPER = state[index];
}
*/

/*
void StepMoveCV(float angle, float rps){
	angle - Degree
	rps - 1rev per second

	static int count = 0;
	int totstep;
	totstep = angle/
}
*/
unsigned int TFlag = 0;

interrupt void ISRNMI()
{
}

interrupt void ISRextint6()
{
	volatile unsigned int tmp;

	while((tmp = *intid_fifo & 0x0F) != 1) {
		if(tmp == 0x04) {
			while(*linestatus&0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				SendByte(*(compacket.wr_ptr));
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
		else if(tmp == 0x02) {
			if(respacket.char_num-- > 0) {
				*txrx_divl = respacket.string[respacket.char_to_send++];
			}
			else {
				*inten_divh = 0x01;			
				respacket.flag = 0;
			}
		}
		else if(tmp == 0x0C) {
			while(*linestatus & 0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
	}
}

interrupt void ISRtimer0()
{
	static unsigned int cnt1K=0;
	static unsigned int cnt=0;
	static float mmag = 0.2f;
	float sig0, sig1, sig2, sig3;
	static unsigned int Dout = 0;

	TFlag = 1;
	Dout = ~Dout;
	*DOUT0 = Dout;

	// Example code to use USBMonitor
	cnt1K++;
	if (cnt1K >= 100) {
		// The codes hearafter are executed at every 100 timer interrupts.
		cnt1K = 0;

		sig0 = 250.0f/tdelay;
		sig1 = mmag*cosf(2.0f*3.141592f/2000.0f*cnt);
		sig2 = mmag*sinf(2.0f*3.141592f/2500.0f*cnt);
		sig3 = mmag*cosf(2.0f*3.141592f/25000.0f*cnt);

		cnt++;
		if ((cnt%5000) == 0) {
			mmag += 0.01f;
			if (mmag > 2.0f) {
				mmag = 0.2f;
			}
		}

		UMAddData(sig0, sig1, sig2, sig3);	// Add 4 data set to USBMon
	}

}

