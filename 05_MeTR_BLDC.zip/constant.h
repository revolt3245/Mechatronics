/* Constant.h */

#define SIZE_OF_COMPACKET 		(100)
#define SIZE_OF_RESPACKET 		(200)

#define CPU_FRQ					(160.0e6f)
#define TIMER_FRQ				(1000.0f)
