/* Main.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "USBMon.h"

#define TARGET -360.0f
extern int CountClock;

float angle;
float target;

int done = 0;

void InitEXINTF()
{
	// Disable SSCEN, CLK1EN, CLK2EN
	*GBLCTL &= 0xFFFFFFC7;

	// WriteSetup[31:28] | WriteStrobe[27:22] | WriteHold[21:20] | ReadSetup[19:16] | 
	// RSVD[15:14] | ReadStrobe[13:8] | RSVD[7] | MType[6:4] | RSVD[3:2] | ReadHold[1:0]
	// DEFAULT = (0xF<<28)|(0x3F<<22)|(0x3<<20)|(0xF<<16)|(0x3F<<8)|(0x2<<4)|(0x3);
	// SRAM
	*CECTL0 = (0x0<<28)|(0x03<<22)|(0x1<<20)|(0x0<<16)|(0x03<<8)|(0x2<<4)|(0x1);

	// IO Space: Async 32bit Mode, Setup 2 and Strobe 5, Hold 1  
	*CECTL2 = (0x2<<28)|(0x05<<22)|(0x1<<20)|(0x2<<16)|(0x05<<8)|(0x2<<4)|(0x1);
}

void InitTimer()
{
	// Hold 0 and Go 0, Internal Clock Source (160Mhz/4), Clock Mode   
	*T0CTL |= 0x00000300;

	// Timer Period
	*T0PRD = (CPU_FRQ/4.0f)/(2.0f*TIMER_FRQ);	// f = 40Mhz/2*Period 

	// Hold 1 and Go 1   
	*T0CTL |= 0x000000C0;
}

void InitINT()
{
	// Enable CPU Interrupt INT06(EXTINT6), INT14(TINT0) and NMI
	IER |= 0x00004042;
}

void GIE()
{
	// Global Interrupt Enable
	CSR |= 0x00000001;
}

// Caution: The delayed time is not exact.
void delay_us(unsigned int time_us)
{
	register unsigned int i;

	for (i = 0; i < (time_us * 14); i++) ;
}

// Caution: The delayed time is not exact.
void delay_ms(unsigned int time_ms)
{
	register unsigned int i;

	for (i = 0; i < time_ms; i++) {
		delay_us(1000);
	}
}

// Wait until timer interrupt
void WaitTFlag()
{
	while (!TFlag) ;
	TFlag = 0;
}

// Waiting time = (Timer Period) * cnt
void WaitTFlagCnt(unsigned int cnt)
{
	unsigned int i;

	TFlag = 0;

	for (i=0; i<cnt; i++) {
		WaitTFlag();
	}
}

void BLDCrotate(int delay){
	*BLDC2 = 0xFFF;		// HIGH
	*BLDC1 = 0x000;		// LOW
	*BLDC0 = 0x800;		// Hi-Z
	delay_us(delay);

	*BLDC2 = 0x800;		// Hi-Z
	*BLDC1 = 0x000;		// LOW
	*BLDC0 = 0xFFF;		// HIGH
	delay_us(delay);

	*BLDC2 = 0x000;		// LOW
	*BLDC1 = 0x800;		// Hi-Z
	*BLDC0 = 0xFFF;		// HIGH
	delay_us(delay);

	*BLDC2 = 0x000;		// LOW
	*BLDC1 = 0xFFF;		// HIGH
	*BLDC0 = 0x800;		// Hi-Z
	delay_us(delay);

	*BLDC2 = 0x800;		// Hi-Z
	*BLDC1 = 0xFFF;		// HIGH
	*BLDC0 = 0x000;		// LOW
	delay_us(delay);

	*BLDC2 = 0xFFF;		// HIGH
	*BLDC1 = 0x800;		// Hi-Z
	*BLDC0 = 0x000;		// LOW
	delay_us(delay);
}

void PhaseOut(unsigned int PWM){
	unsigned int pwm[3];
	char hall;
	/*
		PWM - difference from HiZ to High
	*/
	pwm[2] = PWM;
	pwm[1] = 0xfff-PWM;
	pwm[0] = 0x800;
	hall = (*BLDCHALL)&(0x07);

	switch(hall){
		case 0x5:
		*BLDC2 = pwm[0];
		*BLDC1 = pwm[1];
		*BLDC0 = pwm[2];
		break;
		case 0x4:
		*BLDC2 = pwm[2];
		*BLDC1 = pwm[1];
		*BLDC0 = pwm[0];
		break;
		case 0x6:
		*BLDC2 = pwm[2];
		*BLDC1 = pwm[0];
		*BLDC0 = pwm[1];
		break;
		case 0x2:
		*BLDC2 = pwm[0];
		*BLDC1 = pwm[2];
		*BLDC0 = pwm[1];
		break;
		case 0x3:
		*BLDC2 = pwm[1];
		*BLDC1 = pwm[2];
		*BLDC0 = pwm[0];
		break;
		case 0x1:
		*BLDC2 = pwm[1];
		*BLDC1 = pwm[0];
		*BLDC0 = pwm[2];
		break;
	}
}

void BLDCDrive(float duty){
	/*
		Duty - percent Value of Duty
	*/
	unsigned int pwminput;
	if(duty > 99.99f){
		duty = 99.99f;
	}
	else if (duty < 0.01f){
		duty = 0.01f;
	}
	pwminput = (unsigned int)(4095.0f*duty/100.0f);
	PhaseOut(pwminput);
}

int mapping(char phase){
	int idx;
	switch(phase){
		case 0x5:
		idx = 0;
		break;
		case 0x4:
		idx = 1;
		break;
		case 0x6:
		idx = 2;
		break;
		case 0x2:
		idx = 3;
		break;
		case 0x3:
		idx = 4;
		break;
		case 0x1:
		idx = 5;
		break;
	}
	return idx;
}

int count(){
	static int count = 0;
	static int initcond = 1;
	static int prehallmap;
	char hall;
	int hallmap;

	hall = (*BLDCHALL)&(0x07);
	hallmap = mapping(hall);

	//init condition
	if (initcond){
		prehallmap = hallmap;
		initcond = 0;
	}

	if(hallmap > prehallmap){
		if(hallmap - prehallmap < 3){
			count += hallmap-prehallmap;
		}
		else{
			count -= 6-(hallmap-prehallmap);
		}
	}
	else if(prehallmap > hallmap){
		if(prehallmap - hallmap < 3){
			count -= prehallmap - hallmap;
		}
		else{
			count += 6-(prehallmap - hallmap);
		}
	}
	else{
		count = count;
	}
	prehallmap = hallmap;
	return count;
}

float getAngle(){
	return count()/84.0f*360.0f;
}

void AssignVelocity(float x){
	float duty;
	duty = 50+x/2;
	BLDCDrive(duty);
}

float targetGen(float acc, float Vmax, float Target){
	static float t1, t2;
	static float t;
	static int initcond = 1;
	float RWtime;
	float RValue;

	if(initcond){
		t1 = Vmax/acc;
		t2 = Target/Vmax;
		t = sqrt(Target/acc);
		initcond = 0;
	}

	RWtime = ((float)CountClock)/1000.0f;
	if(t2 <= t1){
		//triangular Profile
		if(RWtime < t){
			RValue = acc/2*RWtime*RWtime;
		}
		else if(RWtime < 2*t){
			RValue = Target - acc/2*(2*t-RWtime)*(2*t-RWtime);
		}
		else{
			RValue = Target;
			done = 1;
		}
	}
	else{
		//Echelon Profile
		if(RWtime < t1){
			RValue = acc/2*RWtime*RWtime;
		}
		else if(RWtime < t2){
			RValue = Vmax/2*(2*RWtime - t1);
		}
		else if(RWtime < t1+t2){
			RValue = Target - acc/2*(t1+t2-RWtime)*(t1+t2-RWtime);
		}
		else{
			RValue = Target;
			done = 1;
		}
	}
	return RValue;
}

void main()
{
	InitEXINTF();	// Asynchronous Bus Initialization
	InitTimer();	// Timer Initialization
	InitUART();		// UART Initialization
	InitINT();		// Interrupt Enable(External INT and Timer INT)
	InitUSBMon();	// USB Monitor Initialization

	MACRO_PRINT((tmp_string, "\r\nMechatronics Course EIE SeoulTech %d\r\n", 2016));
	MACRO_PRINT((tmp_string, "\r\nFPGA Ver%2x.%02x\r\n\n", ((*FPGAVER>>8) & 0xFF), (*FPGAVER & 0xFF)));

	TFlag = 0;

	GIE();

	*BLDCEN = 1;	// BLDC Motor Driver Enable

	while(1) {
		//BLDCDrive(100);
		angle = getAngle();
		target = targetGen(-5000.0f, -10000.0f, TARGET);
	}
}

