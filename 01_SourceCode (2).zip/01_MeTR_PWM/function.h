/* Function.h */

// Serial.c
extern void InitUART();
extern char ReceiveByte();
extern void SendByte(char data);
extern int CheckSum();
extern void SendData();
extern void Report();

