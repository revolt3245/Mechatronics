/* Main.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "USBMon.h"

void InitEXINTF()
{
	// Disable EKEN, CLK1EN, CLK2EN
	*GBLCTL &= 0xFFFFFFC7;

	// WriteSetup[31:28] | WriteStrobe[27:22] | WriteHold[21:20] | ReadSetup[19:16] | 
	// RSVD[15:14] | ReadStrobe[13:8] | RSVD[7] | MType[6:4] | RSVD[3:2] | ReadHold[1:0]
	// Async 32bit Mode, Setup 2 and Strobe 5, Hold 1  
	*CECTL0 = (0x0<<28)|(0x03<<22)|(0x1<<20)|(0x0<<16)|(0x03<<8)|(0x2<<4)|(0x1);
	*CECTL2 |= 0x21520521;
}

void InitTimer()
{
	// Hold 0 and Go 0, Internal Clock Source (160Mhz/4), Clock Mode   
	*T0CTL |= 0x00000300;

	// Timer Period
	*T0PRD = (CPU_FRQ/4.0f)/(2.0f*TIMER_FRQ);				// f = 40Mhz/2*Period 

	// Hold 1 and Go 1   
	*T0CTL |= 0x000000C0;
}

void InitINT()
{
	// Enable CPU Interrupt INT06(EXTINT6), INT14(TINT0) and NMI
	IER |= 0x00004042;
}

void GIE()
{
	// Global Interrupt Enable
	CSR |= 0x00000001;
}

void delay_us(unsigned int time_us)      // time delay(us)
{
    register unsigned int i;
 
	for(i = 0; i < time_us; i++);
 }

void delay_ms(unsigned int time_ms)      
{
    register unsigned int i;
    for(i = 0; i < time_ms; i++)
    {
      delay_us(4500);
      delay_us(4500);
      delay_us(4500);
      delay_us(4500);
    }
}

void PWMOut(float dutyratio){
	/*
		dutyratio - +100 - 0xfff
					-100 - 0x000
	*/
	unsigned int decode;

	decode = (unsigned int)((100+dutyratio) * 4096/200);

	if (dutyratio > 100){
		decode = 0xfff;
	}
	else if(dutyratio < -100){
		decode = 0x000;
	}

	*PWMRIGHT = decode;
}

void main()
{
	InitEXINTF();	// Asynchronous Bus Initialization
	InitTimer();	// Timer Initialization
	InitUART();		// UART Initialization
	InitINT();		// Interrupt Enable(External INT and Timer INT)
	InitUSBMon();	// USB Monitor Initialization

	GIE();

	MACRO_PRINT((tmp_string, "\r\nMechatronics Course EIE SeoulTech %d\r\n", 2019));
	MACRO_PRINT((tmp_string, "\r\nFPGA Ver%2x.%02x\r\n\n", ((*FPGAVER>>8) & 0xFF), (*FPGAVER & 0xFF)));

	*FPGALED = 1;			// FPGA LED 1 : ON, 0 : OFF
	*PWMDRVEN = 1;			// PWMENABLE 1 : ON, 0 : 0FF
	//*PWMRIGHT = 0x800;		// PWM : 0x000 ~ 0x800 ~ 0xFFF

	PWMOut(0);

	while (1) {
	}
}

