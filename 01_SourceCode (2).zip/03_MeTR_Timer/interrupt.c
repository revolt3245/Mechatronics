/* Interupt.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "interrupt.h"
#include "USBMon.h"

#define P_GAIN 3.5f
#define I_GAIN 0.0f
#define D_GAIN 60.0f

#define TARGETANGLE 360.0f
#define SpeedRatio 1.0f

unsigned int cnt;

void PWMOut(float dutyratio){
	/*
		dutyratio - +100 - 0xfff
					-100 - 0x000
	*/
	//float dr;
	unsigned int decode;
	/*
	if (dutyratio > 100){
		dr = 100;
	}
	else if(dutyratio < -100){
		dr = -100;
	}
	else{
		dr = dutyratio;
	}
	*/

	decode = (unsigned int)((100+dutyratio) * 4096/200);

	if (dutyratio > 100){
		decode = 0xfff;
	}
	else if(dutyratio < -100){
		decode = 0x000;
	}

	*PWMRIGHT = decode;
}

float GetAngle(){
	float M_angle;
	float delta;
	unsigned int a;
	a = *ENCPOSR;
	
	delta = 360.0f/(512*7.5);
	
	a &= 0x0000ffff;

	M_angle = (short int)a * delta;
	return M_angle;
}

float PosRef(){
	float start = 0.0f;
	float target = TARGETANGLE;
	static float Referance = 0.0f;
	float acceleration;
	static float velocity = 0.0f;
	float rotatepercent;
	float sr;
	sr = SpeedRatio*SpeedRatio;

	acceleration = 0.0005f*sr/90.0f*(target-start);

	rotatepercent = Referance/(target-start) * 100.0f;

	if (rotatepercent <= 20){
		velocity += acceleration;
	}
	else if(rotatepercent >= 80 && rotatepercent < 100){
		if (velocity > 0){
			velocity -= acceleration;
		}
		else{
			velocity = 0;
			acceleration= 0;
		}
	}
	
	if(Referance >= target){
		Referance = target;
	}
	else{
		Referance += velocity;
	}

	return Referance;
}

interrupt void ISRNMI()
{
}

interrupt void ISRextint6()
{
	volatile unsigned int tmp;

	while((tmp = *intid_fifo & 0x0F) != 1) {
		if(tmp == 0x04) {
			while(*linestatus&0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				SendByte(*(compacket.wr_ptr));
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
		else if(tmp == 0x02) {
			if(respacket.char_num-- > 0) {
				*txrx_divl = respacket.string[respacket.char_to_send++];
			}
			else {
				*inten_divh = 0x01;			
				respacket.flag = 0;
			}
		}
		else if(tmp == 0x0C) {
			while(*linestatus & 0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
	}
}



interrupt void ISRtimer0()
{
	static unsigned int Dout=0;
	static unsigned int cnt=0;
	static float mmag = 0.2f;
	static float Error1 = 0.0f;
	static float Integ = 0.0f;
	float RefAngle;
	float Angle;
	float Error2;
	float PWMinput;

	float sig0, sig1, sig2, sig3;

	Dout = ~Dout;
	*DOUT0 = Dout;

	TINTCnt++;

	//PID Controller
	Angle = GetAngle();
	RefAngle = PosRef();
	Error2 = RefAngle-Angle;
	Integ += Error2;
	PWMinput = P_GAIN*Error2 + D_GAIN*(Error2-Error1) + I_GAIN*Integ;

	PWMOut(PWMinput);

	Error1 = Error2;

	// Example code to use USBMonitor
	sig0 = Angle;
	sig1 = RefAngle;
	sig2 = Error2;
	sig3 = PWMinput;

	cnt++;
	if ((cnt%5000) == 0) {
		mmag += 0.01f;
		if (mmag > 2.0f) {
			mmag = 0.2f;
		}
	}

	UMAddData(sig0, sig1, sig2, sig3);	// Add 4 data set to USBMon
}

